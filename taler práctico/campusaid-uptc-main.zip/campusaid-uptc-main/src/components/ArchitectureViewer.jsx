
import React from 'react';
import {Layers, ShieldCheck, Database, Server, GitBranch, Cpu, Lock, CheckCircle2, Clock, Github, Workflow, Globe, KeyRound, UserRound,Code2} 
  from 'lucide-react';

import { isConfigured } from '../services/supabase';

export default function ArchitectureViewer() {

  // Estados actuales de integración.
  // Estos estados representan el avance conocido del proyecto.
  const infrastructure = [
    {
      name: 'Supabase PostgreSQL',
      description: 'Proyecto creado y tablas relacionales configuradas.',
      status: 'implemented',
      icon: Database
    },
    {
      name: 'Supabase Auth',
      description: 'Registro, inicio de sesión y gestión de sesiones.',
      status: 'pending',
      icon: UserRound
    },
    {
      name: 'Supabase RLS',
      description: 'Políticas de seguridad por estudiante, coordinador y administrador.',
      status: 'pending',
      icon: Lock
    },
    {
      name: 'Supabase CRUD',
      description: 'Integración de React con las operaciones de lectura y escritura.',
      status: 'pending',
      icon: Code2
    },
    {
      name: 'Orquestador n8n',
      description: 'Webhooks, procesamiento, inteligencia artificial y notificaciones.',
      status: 'pending',
      icon: Workflow
    },
    {
      name: 'GitHub Repository',
      description: 'Repositorio del código fuente y control de versiones.',
      status: 'implemented',
      icon: Github
    },
    {
      name: 'Vercel Production',
      description: 'Despliegue de frontend y funciones Serverless.',
      status: 'implemented',
      icon: Globe
    }
  ];

  const statusConfig = {
    implemented: {
      label: 'IMPLEMENTADO',
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
      icon: CheckCircle2
    },
    pending: {
      label: 'PENDIENTE',
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      icon: Clock
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">

      {/* BANNER PRINCIPAL */}

      <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-xl">

        <div className="flex items-center gap-3 mb-2">

          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center">
            <Layers className="w-6 h-6" />
          </div>

          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Arquitectura Segura del Sistema · CampusGest UPTC
            </h2>

            <p className="text-xs sm:text-sm text-slate-400">
              React + GitHub + Vercel Serverless + n8n + Supabase PostgreSQL, Auth y RLS.
            </p>
          </div>

        </div>

        {/* DIAGRAMA DE ARQUITECTURA */}

        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">

          {/* CAPA 1: FRONTEND */}

          <div className="bg-slate-900 border border-amber-400/40 rounded-xl p-5">

            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center mb-3">
              <Cpu className="w-5 h-5" />
            </div>

            <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider">
              Capa 1 · Frontend
            </span>

            <h4 className="font-bold text-white text-sm mt-1">
              CampusGest React UI
            </h4>

            <p className="text-xs text-slate-400 mt-2">
              Interfaz web, dashboard, validaciones de formularios,
              gestión de solicitudes y comunicación con servicios backend.
            </p>

            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              React · Supabase SDK
            </div>

          </div>

          {/* CAPA 2: VERCEL */}

          <div className="bg-slate-900 border border-blue-500/40 rounded-xl p-5">

            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3">
              <Server className="w-5 h-5" />
            </div>

            <span className="text-[11px] font-mono text-blue-400 uppercase tracking-wider">
              Capa 2 · Backend
            </span>

            <h4 className="font-bold text-white text-sm mt-1">
              Vercel Serverless
            </h4>

            <p className="text-xs text-slate-400 mt-2">
              API Gateway, validación de solicitudes, control de acceso,
              gestión de secretos y comunicación con webhooks privados.
            </p>

            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              /api/solicitudes
            </div>

          </div>

          {/* CAPA 3: N8N */}

          <div className="bg-slate-900 border border-amber-500/40 rounded-xl p-5">

            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
              <GitBranch className="w-5 h-5" />
            </div>

            <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider">
              Capa 3 · Automatización
            </span>

            <h4 className="font-bold text-white text-sm mt-1">
              n8n Workflow
            </h4>

            <p className="text-xs text-slate-400 mt-2">
              Clasificación de solicitudes, automatización de procesos,
              integración con IA, consultas y notificaciones por correo.
            </p>

            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              Webhooks · Workflow
            </div>

          </div>

          {/* CAPA 4: SUPABASE */}

          <div className="bg-slate-900 border border-emerald-500/40 rounded-xl p-5">

            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
              <Database className="w-5 h-5" />
            </div>

            <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider">
              Capa 4 · Persistencia
            </span>

            <h4 className="font-bold text-white text-sm mt-1">
              Supabase PostgreSQL
            </h4>

            <p className="text-xs text-slate-400 mt-2">
              Base de datos relacional, autenticación institucional,
              perfiles de usuarios y políticas de seguridad RLS.
            </p>

            <div className="mt-3 space-y-2">

              {[
                'PostgreSQL · Creado',
                'Auth · Pendiente',
                'RLS · Pendiente',
                'CRUD · Pendiente'
              ].map((item) => (
                <div
                  key={item}
                  className="text-[10px] font-mono text-slate-300 bg-slate-950 p-2 rounded border border-slate-800"
                >
                  {item}
                </div>
              ))}

            </div>

          </div>

        </div>

        {/* REPOSITORIO Y DESPLIEGUE */}

        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-4">

          <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center gap-3">

            <Github className="w-7 h-7 text-white" />

            <div>
              <h4 className="text-sm font-bold text-white">
                GitHub Repository
              </h4>
              <p className="text-xs text-slate-400">
                Código fuente y control de versiones.
              </p>
            </div>

          </div>

          <div className="bg-slate-900 border border-blue-500/30 rounded-xl p-4 flex items-center gap-3">

            <Globe className="w-7 h-7 text-blue-400" />

            <div>
              <h4 className="text-sm font-bold text-white">
                Vercel Deployment
              </h4>
              <p className="text-xs text-slate-400">
                Producción y despliegue del proyecto.
              </p>
            </div>

          </div>

        </div>

      </div>

      {/* SEGURIDAD Y AUDITORÍA */}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* CONTROLES DE SEGURIDAD */}

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">

          <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Controles de Seguridad y OWASP
          </h3>

          <ul className="space-y-3 text-xs text-slate-300">

            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Sin autenticación ficticia:</strong>
                Eliminación del auto-login simulado y de la selección pública de roles administrativos.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>API con respuestas controladas:</strong>
                Manejo explícito de errores y respuestas HTTP adecuadas cuando los servicios no están disponibles.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Validación de datos:</strong>
                Whitelisting de campos y límites de tamaño de solicitudes.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Protección SQL:</strong>
                Uso de consultas parametrizadas en las operaciones PostgreSQL.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <Clock className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Autorización RLS:</strong>
                Pendiente de implementación y pruebas sobre las tablas sensibles.
              </span>
            </li>

          </ul>

        </div>

        {/* ESTADO DE INTEGRACIÓN */}

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">

          <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
            <Database className="w-5 h-5 text-emerald-400" />
            Estado de Integración de Infraestructura
          </h3>

          <div className="space-y-3">

            {infrastructure.map((item) => {

              const status = statusConfig[item.status];
              const Icon = item.icon;
              const StatusIcon = status.icon;

              return (
                <div
                  key={item.name}
                  className="flex items-start gap-3"
                >

                  <Icon className="w-4 h-4 text-slate-400 flex-shrink-0 mt-1" />

                  <div className="flex-1 min-w-0">

                    <div className="flex flex-wrap items-center gap-2">

                      <strong className="text-xs text-slate-200">
                        {item.name}
                      </strong>

                      <span
                        className={`text-[9px] font-bold px-2 py-1 rounded border ${status.color} ${status.bg} ${status.border}`}
                      >
                        {status.label}
                      </span>

                    </div>

                    <p className="text-[11px] text-slate-400 mt-1">
                      {item.description}
                    </p>

                  </div>

                  <StatusIcon
                    className={`w-4 h-4 flex-shrink-0 ${status.color}`}
                  />

                </div>
              );

            })}

          </div>

        </div>

      </div>

      {/* CONFIGURACIÓN DEL PROYECTO */}

      <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">

        <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
          <KeyRound className="w-5 h-5 text-blue-400" />
          Configuración de Servicios
        </h3>

        <div className="flex items-center justify-between gap-3 flex-wrap">

          <div>
            <p className="text-sm text-white font-semibold">
              Configuración del cliente Supabase
            </p>

            <p className="text-xs text-slate-400 mt-1">
              Verificación de disponibilidad de las variables de entorno.
            </p>
          </div>

          <span
            className={`text-[10px] font-bold px-3 py-2 rounded-lg ${
              isConfigured
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
            }`}
          >
            {isConfigured
              ? 'CONFIGURACIÓN DETECTADA'
              : 'CONFIGURACIÓN PENDIENTE'}
          </span>

        </div>

        <p className="text-[11px] text-slate-500 mt-4">
          Nota: la presencia de variables de entorno no garantiza que la conexión,
          autenticación, permisos RLS o consultas a PostgreSQL funcionen correctamente.
          Estos componentes deben verificarse mediante pruebas independientes.
        </p>

      </div>

    </div>
  );
}

