-- ====================================================================
-- MIGRACIÓN DE PRODUCCIÓN: CampusAid UPTC
-- Basada en los esquemas institucionales de ejemplos/estructura-supabase.sql
-- Incluye DDL de 10 tablas relacionales, RLS, triggers y semillas reales
-- ====================================================================

-- 1. Extensión para UUIDs
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Tabla de estudiantes
CREATE TABLE IF NOT EXISTS public.estudiantes (
    id_estudiante UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    codigo_uptc VARCHAR(9) UNIQUE NOT NULL
        CHECK (codigo_uptc ~ '^[0-9]{9}$'),
    email_institucional VARCHAR(150) UNIQUE NOT NULL
        CHECK (email_institucional ~* '^[A-Z0-9._%+-]+@uptc\.edu\.co$'),
    programa_academico VARCHAR(120),
    semestre INTEGER CHECK (semestre BETWEEN 1 AND 20),
    telefono VARCHAR(20),
    creado_en TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Tabla de docentes
CREATE TABLE IF NOT EXISTS public.docentes (
    id_docente UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email_institucional VARCHAR(150) UNIQUE NOT NULL,
    departamento VARCHAR(100),
    especialidad VARCHAR(150),
    telefono VARCHAR(20),
    disponibilidad BOOLEAN DEFAULT TRUE
);

-- 4. Tabla de coordinadores
CREATE TABLE IF NOT EXISTS public.coordinadores (
    id_coordinador UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email_institucional VARCHAR(150) UNIQUE NOT NULL,
    area_responsable VARCHAR(100) NOT NULL,
    cargo VARCHAR(100),
    telefono VARCHAR(20)
);

-- 5. Tabla principal de solicitudes de campus
CREATE TABLE IF NOT EXISTS public.solicitudes_campus (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_estudiante UUID REFERENCES public.estudiantes(id_estudiante) ON DELETE SET NULL,
    id_coordinador UUID REFERENCES public.coordinadores(id_coordinador) ON DELETE SET NULL,
    tipo_tramite VARCHAR(20) NOT NULL
        CHECK (tipo_tramite IN ('Tutoria', 'Laboratorio', 'Certificado')),
    descripcion TEXT NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente'
        CHECK (estado IN (
            'Pendiente',
            'Asignada',
            'En proceso',
            'Aprobada',
            'Rechazada',
            'Finalizada',
            'Cancelada'
        )),
    -- Columnas adicionales de compatibilidad y trazabilidad
    estudiante_nombre VARCHAR(150),
    codigo_uptc VARCHAR(9),
    email_institucional VARCHAR(255),
    asignatura_o_lab VARCHAR(200),
    area_asignada VARCHAR(100),
    observacion_coordinador TEXT,
    request_id UUID UNIQUE,
    creado_en TIMESTAMPTZ DEFAULT NOW(),
    actualizado_en TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Tabla de solicitudes de tutorías
CREATE TABLE IF NOT EXISTS public.solicitudes_tutorias (
    id_tutoria UUID PRIMARY KEY
        REFERENCES public.solicitudes_campus(id)
        ON DELETE CASCADE,
    id_docente UUID
        REFERENCES public.docentes(id_docente)
        ON DELETE SET NULL,
    asignatura VARCHAR(120) NOT NULL,
    tema VARCHAR(150),
    fecha_tutoria TIMESTAMPTZ,
    modalidad VARCHAR(20)
        CHECK (modalidad IN ('Presencial', 'Virtual')),
    observaciones TEXT
);

-- 7. Tabla de laboratorios
CREATE TABLE IF NOT EXISTS public.laboratorios (
    id_laboratorio UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(150),
    capacidad INTEGER CHECK (capacidad > 0),
    descripcion TEXT,
    recursos_disponibles TEXT,
    disponible BOOLEAN DEFAULT TRUE
);

-- 8. Tabla de préstamos de laboratorios
CREATE TABLE IF NOT EXISTS public.prestamos_laboratorios (
    id_prestamo UUID PRIMARY KEY
        REFERENCES public.solicitudes_campus(id)
        ON DELETE CASCADE,
    id_laboratorio UUID NOT NULL
        REFERENCES public.laboratorios(id_laboratorio),
    fecha_reserva DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    motivo TEXT NOT NULL,
    cantidad_personas INTEGER NOT NULL
        CHECK (cantidad_personas > 0),
    CHECK (hora_fin > hora_inicio)
);

-- 9. Tabla de solicitudes de certificados
CREATE TABLE IF NOT EXISTS public.solicitudes_certificados (
    id_certificado UUID PRIMARY KEY
        REFERENCES public.solicitudes_campus(id)
        ON DELETE CASCADE,
    tipo_certificado VARCHAR(100) NOT NULL,
    fecha_emision TIMESTAMPTZ,
    numero_certificado VARCHAR(50) UNIQUE,
    archivo_pdf TEXT
);

-- 10. Tabla de notificaciones
CREATE TABLE IF NOT EXISTS public.notificaciones (
    id_notificacion UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_solicitud UUID NOT NULL
        REFERENCES public.solicitudes_campus(id)
        ON DELETE CASCADE,
    mensaje TEXT NOT NULL,
    tipo_notificacion VARCHAR(30),
    canal VARCHAR(20) DEFAULT 'Correo',
    fecha_envio TIMESTAMPTZ DEFAULT NOW(),
    estado_envio VARCHAR(20) DEFAULT 'Pendiente'
        CHECK (estado_envio IN ('Pendiente', 'Enviado', 'Fallido'))
);

-- 11. Tabla de historial de estados
CREATE TABLE IF NOT EXISTS public.historial_solicitudes (
    id_historial UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_solicitud UUID NOT NULL
        REFERENCES public.solicitudes_campus(id)
        ON DELETE CASCADE,
    estado_anterior VARCHAR(20),
    estado_nuevo VARCHAR(20) NOT NULL,
    observacion TEXT,
    fecha_cambio TIMESTAMPTZ DEFAULT NOW()
);

-- ====================================================================
-- HABILITAR ROW LEVEL SECURITY (RLS) EN PRODUCCIÓN
-- ====================================================================

ALTER TABLE public.estudiantes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.docentes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coordinadores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.solicitudes_campus ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.solicitudes_tutorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.laboratorios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prestamos_laboratorios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.solicitudes_certificados ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notificaciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.historial_solicitudes ENABLE ROW LEVEL SECURITY;

-- Políticas de lectura para catálogos y tablas públicas
DROP POLICY IF EXISTS "lectura_docentes" ON public.docentes;
CREATE POLICY "lectura_docentes" ON public.docentes FOR SELECT TO public USING (true);

DROP POLICY IF EXISTS "lectura_coordinadores" ON public.coordinadores;
CREATE POLICY "lectura_coordinadores" ON public.coordinadores FOR SELECT TO public USING (true);

DROP POLICY IF EXISTS "lectura_laboratorios" ON public.laboratorios;
CREATE POLICY "lectura_laboratorios" ON public.laboratorios FOR SELECT TO public USING (true);

-- Políticas para estudiantes
DROP POLICY IF EXISTS "estudiantes_select" ON public.estudiantes;
CREATE POLICY "estudiantes_select" ON public.estudiantes FOR SELECT TO public USING (true);

DROP POLICY IF EXISTS "estudiantes_insert" ON public.estudiantes;
CREATE POLICY "estudiantes_insert" ON public.estudiantes FOR INSERT TO public WITH CHECK (true);

-- Políticas para solicitudes_campus
DROP POLICY IF EXISTS "solicitudes_select_public" ON public.solicitudes_campus;
CREATE POLICY "solicitudes_select_public" ON public.solicitudes_campus FOR SELECT TO public USING (true);

DROP POLICY IF EXISTS "solicitudes_insert_public" ON public.solicitudes_campus;
CREATE POLICY "solicitudes_insert_public" ON public.solicitudes_campus FOR INSERT TO public WITH CHECK (true);

DROP POLICY IF EXISTS "solicitudes_update_auth" ON public.solicitudes_campus;
CREATE POLICY "solicitudes_update_auth" ON public.solicitudes_campus FOR UPDATE TO public USING (true);

-- Políticas para tablas hijas de trámites
DROP POLICY IF EXISTS "tutorias_all" ON public.solicitudes_tutorias;
CREATE POLICY "tutorias_all" ON public.solicitudes_tutorias FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "prestamos_all" ON public.prestamos_laboratorios;
CREATE POLICY "prestamos_all" ON public.prestamos_laboratorios FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "certificados_all" ON public.solicitudes_certificados;
CREATE POLICY "certificados_all" ON public.solicitudes_certificados FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "notificaciones_all" ON public.notificaciones;
CREATE POLICY "notificaciones_all" ON public.notificaciones FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "historial_all" ON public.historial_solicitudes;
CREATE POLICY "historial_all" ON public.historial_solicitudes FOR ALL TO public USING (true) WITH CHECK (true);

-- ====================================================================
-- SEMILLAS INSTITUCIONALES EN PRODUCCIÓN (Caso 3 · CampusAid UPTC)
-- ====================================================================

-- 1. Coordinadores institucionales
INSERT INTO public.coordinadores (id_coordinador, nombre, apellido, email_institucional, area_responsable, cargo)
VALUES 
    ('c1111111-1111-4111-c111-111111111111', 'Marcela', 'Pérez Vargas', 'coordinacion.academica@uptc.edu.co', 'Coordinación Académica', 'Coordinadora de Tutorías'),
    ('c2222222-2222-4222-c222-222222222222', 'Ing. Javier', 'Rincón Mora', 'laboratorios.ingenieria@uptc.edu.co', 'Responsable de Laboratorios', 'Jefe de Laboratorios de Ingeniería'),
    ('c3333333-3333-4333-c333-333333333333', 'Dra. Gloria', 'Suárez Niño', 'admisiones.certificados@uptc.edu.co', 'Responsable de Certificados y Admisiones', 'Directora de Admisiones')
ON CONFLICT (id_coordinador) DO NOTHING;

-- 2. Docentes para tutorías
INSERT INTO public.docentes (id_docente, nombre, apellido, email_institucional, departamento, especialidad)
VALUES
    ('d1111111-1111-4111-d111-111111111111', 'Alonso', 'Jiménez Pedraza', 'alonso.jimenez@uptc.edu.co', 'Matemáticas y Estadística', 'Cálculo Diferencial e Integral'),
    ('d2222222-2222-4222-d222-222222222222', 'Sonia', 'Barrera Castro', 'sonia.barrera@uptc.edu.co', 'Ingeniería de Sistemas', 'Redes y Telecomunicaciones')
ON CONFLICT (id_docente) DO NOTHING;

-- 3. Laboratorios
INSERT INTO public.laboratorios (id_laboratorio, nombre, ubicacion, capacidad, descripcion, recursos_disponibles)
VALUES
    ('l1111111-1111-4111-l111-111111111111', 'Laboratorio de Redes y Telecomunicaciones', 'Edificio Central - Piso 3 - Lab 304', 30, 'Laboratorio especializado en redes y arquitectura de telecomunicaciones', 'Routers Cisco, Switches VLAN, Racks de cableado estructurado, Generadores de señal'),
    ('l2222222-2222-4222-l222-222222222222', 'Laboratorio de Sistemas Inteligentes y Software', 'Edificio de Ingeniería - Lab 201', 35, 'Laboratorio de desarrollo de software y computación gráfica', 'Equipos Core i7, GPU dedicada, Servidor local de pruebas')
ON CONFLICT (id_laboratorio) DO NOTHING;

-- 4. Estudiantes iniciales
INSERT INTO public.estudiantes (id_estudiante, nombre, apellido, codigo_uptc, email_institucional, programa_academico, semestre)
VALUES
    ('e1111111-1111-4111-e111-111111111111', 'Laura Marcela', 'Gómez', '202410045', 'laura.gomez@uptc.edu.co', 'Ingeniería de Sistemas y Computación', 3),
    ('e2222222-2222-4222-e222-222222222222', 'Carlos Andrés', 'Salamanca', '202320112', 'carlos.salamanca@uptc.edu.co', 'Ingeniería Electrónica', 5),
    ('e3333333-3333-4333-e333-333333333333', 'Valentina', 'Rojas Niño', '202210874', 'valentina.rojas@uptc.edu.co', 'Ingeniería Industrial', 7)
ON CONFLICT (id_estudiante) DO NOTHING;

-- 5. Solicitudes de los tres tipos (Tutoria, Laboratorio, Certificado)
INSERT INTO public.solicitudes_campus (
    id,
    id_estudiante,
    id_coordinador,
    tipo_tramite,
    descripcion,
    estado,
    estudiante_nombre,
    codigo_uptc,
    email_institucional,
    asignatura_o_lab,
    area_asignada,
    request_id
)
VALUES
(
    'a1111111-1111-4111-a111-111111111111',
    'e1111111-1111-4111-e111-111111111111',
    'c1111111-1111-4111-c111-111111111111',
    'Tutoria',
    'Requiero apoyo y tutoría para comprensión de integrales definidas y métodos de sustitución antes del examen parcial final.',
    'Pendiente',
    'Laura Marcela Gómez',
    '202410045',
    'laura.gomez@uptc.edu.co',
    'Cálculo Diferencial e Integral',
    'Coordinación Académica',
    'b1111111-1111-4111-b111-111111111111'
),
(
    'a2222222-2222-4222-a222-222222222222',
    'e2222222-2222-4222-e222-222222222222',
    'c2222222-2222-4222-c222-222222222222',
    'Laboratorio',
    'Solicitud de acceso al laboratorio de redes de la Facultad de Ingeniería para configuración física de routers Cisco y switches VLAN.',
    'En revisión',
    'Carlos Andrés Salamanca',
    '202320112',
    'carlos.salamanca@uptc.edu.co',
    'Redes de Computadores y Telecomunicaciones',
    'Responsable de Laboratorios',
    'b2222222-2222-4222-b222-222222222222'
),
(
    'a3333333-3333-4333-a333-333333333333',
    'e3333333-3333-4333-e333-333333333333',
    'c3333333-3333-4333-c333-333333333333',
    'Certificado',
    'Expedición de certificado oficial de notas y promedio acumulado para postulación a pasantía de investigación con Colciencias.',
    'Aprobada',
    'Valentina Rojas Niño',
    '202210874',
    'valentina.rojas@uptc.edu.co',
    'Certificado de Calificaciones Oficial y Buena Conducta',
    'Responsable de Certificados y Admisiones',
    'b3333333-3333-4333-b333-333333333333'
)
ON CONFLICT (id) DO NOTHING;

-- 6. Detalles en tablas hijas
INSERT INTO public.solicitudes_tutorias (id_tutoria, id_docente, asignatura, tema, modalidad)
VALUES (
    'a1111111-1111-4111-a111-111111111111',
    'd1111111-1111-4111-d111-111111111111',
    'Cálculo Diferencial e Integral',
    'Integrales definidas y métodos de sustitución',
    'Presencial'
)
ON CONFLICT (id_tutoria) DO NOTHING;

INSERT INTO public.prestamos_laboratorios (id_prestamo, id_laboratorio, fecha_reserva, hora_inicio, hora_fin, motivo, cantidad_personas)
VALUES (
    'a2222222-2222-4222-a222-222222222222',
    'l1111111-1111-4111-l111-111111111111',
    CURRENT_DATE + INTERVAL '2 days',
    '14:00:00',
    '16:00:00',
    'Configuración física de switches y routers Cisco',
    4
)
ON CONFLICT (id_prestamo) DO NOTHING;

INSERT INTO public.solicitudes_certificados (id_certificado, tipo_certificado, numero_certificado)
VALUES (
    'a3333333-3333-4333-a333-333333333333',
    'Certificado Oficial de Calificaciones y Buena Conducta',
    'CERT-2026-004521'
)
ON CONFLICT (id_certificado) DO NOTHING;
