import React from 'react';
import {
  Layers,
  ShieldCheck,
  Database,
  Server,
  GitBranch,
  Cpu,
  Lock,
  CheckCircle2,
  Github,
  Workflow,
  Globe,
  KeyRound,
  UserRound,
  Code2
} from 'lucide-react';
import { isConfigured } from '../services/supabase';

export default function ArchitectureViewer() {
  // Estados de infraestructura en producción
  const infrastructure = [
    {
      name: 'Supabase PostgreSQL',
      description: 'Base de datos PostgreSQL en producción con tablas relacionales de CampusAid.',
      status: 'implemented',
      icon: Database
    },
    {
      name: 'Supabase Auth',
      description: 'Autenticación institucional conectada con Supabase y control de sesiones.',
      status: 'implemented',
      icon: UserRound
    },
    {
      name: 'Supabase RLS',
      description: 'Políticas Row Level Security activas en producción para aislamiento por usuario.',
      status: 'implemented',
      icon: Lock
    },
    {
      name: 'Supabase CRUD',
      description: 'Integración completa de React con operaciones de lectura y persistencia.',
      status: 'implemented',
      icon: Code2
    },
    {
      name: 'Orquestador n8n',
      description: 'Webhooks, clasificación de solicitudes y notificaciones institucionales.',
      status: 'implemented',
      icon: Workflow
    },
    {
      name: 'GitHub Repository',
      description: 'Repositorio del código fuente y control de versiones.',
      status: 'implemented',
      icon: Github
    },
    {
      name: 'Vercel Production',
      description: 'Despliegue de frontend y funciones Serverless.',
      status: 'implemented',
      icon: Globe
    }
  ];

  const statusConfig = {
    implemented: {
      label: 'PRODUCCIÓN',
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
      icon: CheckCircle2
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* BANNER PRINCIPAL */}
      <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Arquitectura Segura del Sistema · CampusGest UPTC
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              React + GitHub + Vercel Serverless + Supabase PostgreSQL (Producción), Auth y RLS.
            </p>
          </div>
        </div>

        {/* DIAGRAMA DE ARQUITECTURA */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* CAPA 1: FRONTEND */}
          <div className="bg-slate-900 border border-amber-400/40 rounded-xl p-5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center mb-3">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider">
              Capa 1 · Frontend
            </span>
            <h4 className="font-bold text-white text-sm mt-1">CampusGest React UI</h4>
            <p className="text-xs text-slate-400 mt-2">
              Interfaz web, dashboard de estudiantes y coordinadores, validaciones UPTC y sincronización en tiempo real.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              React · Supabase SDK
            </div>
          </div>

          {/* CAPA 2: VERCEL */}
          <div className="bg-slate-900 border border-blue-500/40 rounded-xl p-5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3">
              <Server className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-blue-400 uppercase tracking-wider">
              Capa 2 · Backend
            </span>
            <h4 className="font-bold text-white text-sm mt-1">Vercel Serverless</h4>
            <p className="text-xs text-slate-400 mt-2">
              API Gateway `/api/solicitudes`, validación de esquemas, idempotencia y enrutamiento seguro.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              /api/solicitudes
            </div>
          </div>

          {/* CAPA 3: N8N */}
          <div className="bg-slate-900 border border-amber-500/40 rounded-xl p-5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
              <GitBranch className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider">
              Capa 3 · Automatización
            </span>
            <h4 className="font-bold text-white text-sm mt-1">n8n Workflow</h4>
            <p className="text-xs text-slate-400 mt-2">
              Clasificación de trámites, Switch de áreas académicas, auditoría y correos institucionales.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-400 bg-slate-950 p-2 rounded border border-slate-800">
              Webhooks · Workflow
            </div>
          </div>

          {/* CAPA 4: SUPABASE */}
          <div className="bg-slate-900 border border-emerald-500/40 rounded-xl p-5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
              <Database className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider">
              Capa 4 · Persistencia
            </span>
            <h4 className="font-bold text-white text-sm mt-1">Supabase PostgreSQL</h4>
            <p className="text-xs text-slate-400 mt-2">
              Esquemas relacionales normalizados: estudiantes, coordinadores, trámites, préstamos y notificaciones.
            </p>
            <div className="mt-3 space-y-1.5">
              {[
                'PostgreSQL · Producción',
                'Auth · Producción',
                'RLS · Producción',
                'CRUD · Producción'
              ].map((item) => (
                <div
                  key={item}
                  className="text-[10px] font-mono text-emerald-300 bg-slate-950 p-1.5 rounded border border-emerald-500/30 flex items-center justify-between"
                >
                  <span>{item}</span>
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* REPOSITORIO Y DESPLIEGUE */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <Github className="w-7 h-7 text-white" />
            <div>
              <h4 className="text-sm font-bold text-white">GitHub Repository</h4>
              <p className="text-xs text-slate-400">Código fuente, control de versiones y migraciones.</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-blue-500/30 rounded-xl p-4 flex items-center gap-3">
            <Globe className="w-7 h-7 text-blue-400" />
            <div>
              <h4 className="text-sm font-bold text-white">Vercel Deployment</h4>
              <p className="text-xs text-slate-400">Despliegue activo y conectado en producción con Supabase.</p>
            </div>
          </div>
        </div>
      </div>

      {/* SEGURIDAD Y AUDITORÍA */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* CONTROLES DE SEGURIDAD */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">
          <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Controles de Seguridad y OWASP
          </h3>
          <ul className="space-y-3 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Autenticación Institucional:</strong>
                Integración con Supabase Auth restringida a cuentas con dominio @uptc.edu.co.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>API con respuestas controladas:</strong>
                Manejo explícito de códigos HTTP y persistencia segura en base de datos.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Validación de datos:</strong>
                Whitelisting de campos, validación de código numérico de 9 dígitos y límite de 50 KB.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Protección SQL:</strong>
                Consultas parametrizadas en todas las operaciones sobre PostgreSQL.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Autorización RLS en Producción:</strong>
                Políticas activas sobre las tablas relacionales garantizando aislamiento por identidad.
              </span>
            </li>
          </ul>
        </div>

        {/* ESTADO DE INTEGRACIÓN */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">
          <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
            <Database className="w-5 h-5 text-emerald-400" />
            Estado de Infraestructura en Producción
          </h3>
          <div className="space-y-3">
            {infrastructure.map((item) => {
              const status = statusConfig[item.status];
              const Icon = item.icon;
              const StatusIcon = status.icon;

              return (
                <div key={item.name} className="flex items-start gap-3">
                  <Icon className="w-4 h-4 text-slate-400 flex-shrink-0 mt-1" />
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <strong className="text-xs text-slate-200">{item.name}</strong>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${status.color} ${status.bg} ${status.border}`}>
                        {status.label}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{item.description}</p>
                  </div>
                  <StatusIcon className={`w-4 h-4 flex-shrink-0 ${status.color}`} />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* CONFIGURACIÓN DEL PROYECTO */}
      <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6">
        <h3 className="font-bold text-white text-base flex items-center gap-2 mb-4">
          <KeyRound className="w-5 h-5 text-emerald-400" />
          Conexión Supabase PostgreSQL en Producción
        </h3>
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <p className="text-sm text-white font-semibold">
              Cliente Supabase Conectado
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Esquemas relacionales sincronizados con <code className="text-amber-400 font-mono">ejemplos/estructura-supabase.sql</code>.
            </p>
          </div>
          <span className="text-[10px] font-bold px-3 py-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            PRODUCCIÓN · CONECTADO
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-3">
          Las solicitudes radicadas se almacenan directamente en la base de datos PostgreSQL institucional, respetando las restricciones de integridad y las políticas RLS.
        </p>
      </div>

      {/* EXPLORADOR DE ESQUEMAS RELACIONALES (ejemplos/estructura-supabase.sql) */}
      <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap border-b border-slate-700/60 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                Esquema de Base de Datos · 10 Tablas Relacionales
              </h3>
              <p className="text-xs text-slate-400">
                Estructura oficial de persistencia definida en <code className="text-amber-400 font-mono">ejemplos/estructura-supabase.sql</code>
              </p>
            </div>
          </div>
          <span className="text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 px-2.5 py-1 rounded-full font-semibold">
            PostgreSQL 15+ · RLS Activo
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2">
          {[
            {
              nombre: 'solicitudes_campus',
              tipo: 'Tabla Central',
              desc: 'Registro principal de trámites académicos con tipo de trámite, estado y llaves foráneas a estudiantes y coordinadores.',
              cols: 'id (PK), id_estudiante (FK), id_coordinador (FK), tipo_tramite, descripcion, estado, creado_en, actualizado_en'
            },
            {
              nombre: 'estudiantes',
              tipo: 'Entidad de Identidad',
              desc: 'Población estudiantil UPTC con código institucional de 9 dígitos y correo institucional obligatorio.',
              cols: 'id_estudiante (PK), nombre, apellido, codigo_uptc (UNIQUE), email_institucional (UNIQUE), programa_academico, semestre'
            },
            {
              nombre: 'coordinadores',
              tipo: 'Entidad Administrativa',
              desc: 'Coordinadores de áreas académicas responsables de revisar y aprobar los trámites.',
              cols: 'id_coordinador (PK), nombre, apellido, email_institucional, area_responsable, cargo, telefono'
            },
            {
              nombre: 'docentes',
              tipo: 'Cuerpo Docente',
              desc: 'Docentes disponibles de la UPTC asignados para orientar las sesiones de tutoría.',
              cols: 'id_docente (PK), nombre, apellido, email_institucional, departamento, especialidad, disponibilidad'
            },
            {
              nombre: 'solicitudes_tutorias',
              tipo: 'Especialización',
              desc: 'Subtipo para tutorías con asignatura, tema de refuerzo y modalidad (Presencial / Virtual).',
              cols: 'id_tutoria (PK, FK), id_docente (FK), asignatura, tema, fecha_tutoria, modalidad, observaciones'
            },
            {
              nombre: 'laboratorios',
              tipo: 'Catálogo de Recursos',
              desc: 'Espacios y laboratorios de la Facultad de Ingeniería disponibles con capacidad y recursos.',
              cols: 'id_laboratorio (PK), nombre, ubicacion, capacidad, descripcion, recursos_disponibles, disponible'
            },
            {
              nombre: 'prestamos_laboratorios',
              tipo: 'Especialización',
              desc: 'Subtipo para reservas y préstamos de laboratorios con fecha, hora inicio, hora fin y cupo.',
              cols: 'id_prestamo (PK, FK), id_laboratorio (FK), fecha_reserva, hora_inicio, hora_fin, motivo, cantidad_personas'
            },
            {
              nombre: 'solicitudes_certificados',
              tipo: 'Especialización',
              desc: 'Subtipo para solicitud y emisión de certificados oficiales de notas, conducta y matrícula.',
              cols: 'id_certificado (PK, FK), tipo_certificado, fecha_emision, numero_certificado (UNIQUE), archivo_pdf'
            },
            {
              nombre: 'historial_solicitudes',
              tipo: 'Auditoría',
              desc: 'Trazabilidad inmutable de cada cambio de estado realizado por los coordinadores.',
              cols: 'id_historial (PK), id_solicitud (FK), estado_anterior, estado_nuevo, observacion, fecha_cambio'
            },
            {
              nombre: 'notificaciones',
              tipo: 'Comunicaciones',
              desc: 'Registro de notificaciones por correo institucional enviadas a estudiantes y áreas asignadas.',
              cols: 'id_notificacion (PK), id_solicitud (FK), mensaje, tipo_notificacion, canal, fecha_envio, estado_envio'
            }
          ].map((t) => (
            <div key={t.nombre} className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-4 space-y-2 hover:border-emerald-500/40 transition">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-bold text-emerald-400">
                  public.{t.nombre}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  {t.tipo}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {t.desc}
              </p>
              <div className="text-[11px] font-mono text-slate-500 bg-slate-950 p-2 rounded border border-slate-800/80 break-words">
                <span className="text-slate-400 font-semibold">Columnas: </span>{t.cols}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
