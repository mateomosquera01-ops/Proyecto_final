/**
 * Módulo de Integración con Supabase en Producción
 * Compatible con la estructura relacional de esquemas UPTC (ejemplos/estructura-supabase.sql)
 * Manejo de cliente, consultas con RLS y gestión transparente de persistencia.
 */

import { createClient } from '@supabase/supabase-js';

// Credenciales institucionales de producción de Supabase
const DEFAULT_SUPABASE_URL = 'https://twbjwvjiwgzgerhvpvcs.supabase.co';
const DEFAULT_SUPABASE_KEY = 'sb_publishable_gtGi-ZCLZ5u66Lkbjetz7A_WgkB8cDy';

const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_URL ||
  DEFAULT_SUPABASE_URL;

const supabaseKey =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  DEFAULT_SUPABASE_KEY;

// Determinación limpia de si Supabase tiene credenciales reales configuradas
export const isConfigured = Boolean(
  supabaseUrl &&
  supabaseKey &&
  !supabaseUrl.includes('TU_PROYECTO') &&
  !supabaseKey.includes('REEMPLAZAR') &&
  !supabaseKey.includes('TU_SUPABASE')
);

export const supabase = isConfigured
  ? createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    })
  : null;

// Almacén local para garantizar persistencia y trazabilidad de solicitudes radicadas en el frontend
export const LOCAL_SOLICITUDES_KEY = 'campusaid_solicitudes_locales';

export function getSolicitudesLocales() {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return [];
    const raw = window.localStorage.getItem(LOCAL_SOLICITUDES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function registrarSolicitudLocal(solicitud) {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return [solicitud];
    const actuales = getSolicitudesLocales();
    const filtradas = actuales.filter(s => s.id !== solicitud.id);
    const actualizadas = [solicitud, ...filtradas];
    window.localStorage.setItem(LOCAL_SOLICITUDES_KEY, JSON.stringify(actualizadas));
    return actualizadas;
  } catch (e) {
    return [solicitud];
  }
}

// Semillas estáticas de demostración para fallback
const DEMO_SEEDS = [
  {
    id: 'a1111111-1111-4111-a111-111111111111',
    estudiante_id: 'demo-estudiante-local',
    estudiante_nombre: 'Laura Marcela Gómez',
    codigo_uptc: '202410045',
    email_institucional: 'laura.gomez@uptc.edu.co',
    tipo_tramite: 'Tutoria',
    asignatura_o_lab: 'Cálculo Diferencial e Integral',
    descripcion: 'Requiero apoyo y tutoría para comprensión de integrales definidas y métodos de sustitución antes del examen parcial final.',
    estado: 'Pendiente',
    area_asignada: 'Coordinación Académica',
    request_id: 'b1111111-1111-4111-b111-111111111111',
    creado_en: '2026-11-14T10:00:00.000Z'
  },
  {
    id: 'a2222222-2222-4222-a222-222222222222',
    estudiante_id: 'demo-estudiante-2',
    estudiante_nombre: 'Carlos Andrés Salamanca',
    codigo_uptc: '202320112',
    email_institucional: 'carlos.salamanca@uptc.edu.co',
    tipo_tramite: 'Laboratorio',
    asignatura_o_lab: 'Redes de Computadores y Telecomunicaciones',
    descripcion: 'Solicitud de acceso al laboratorio de redes de la Facultad de Ingeniería para configuración física de routers Cisco y switches VLAN.',
    estado: 'En revisión',
    area_asignada: 'Responsable de Laboratorios',
    request_id: 'b2222222-2222-4222-b222-222222222222',
    creado_en: '2026-11-14T14:30:00.000Z'
  },
  {
    id: 'a3333333-3333-4333-a333-333333333333',
    estudiante_id: 'demo-estudiante-3',
    estudiante_nombre: 'Valentina Rojas Niño',
    codigo_uptc: '202210874',
    email_institucional: 'valentina.rojas@uptc.edu.co',
    tipo_tramite: 'Certificado',
    asignatura_o_lab: 'Certificado de Calificaciones Oficial y Buena Conducta',
    descripcion: 'Expedición de certificado oficial de notas y promedio acumulado para postulación a pasantía de investigación con Colciencias.',
    estado: 'Aprobada',
    area_asignada: 'Responsable de Certificados y Admisiones',
    request_id: 'b3333333-3333-4333-b333-333333333333',
    creado_en: '2026-11-15T09:15:00.000Z'
  }
];

/**
 * Consulta solicitudes respetando RLS en Supabase
 * Soporta el esquema relacional normalizado (estudiantes, coordinadores, subtipos)
 * fusionando con las solicitudes locales del estudiante.
 */
export async function fetchSolicitudes(user) {
  const locales = getSolicitudesLocales();

  if (!isConfigured || !supabase) {
    const combinadas = [...locales, ...DEMO_SEEDS.filter(d => !locales.some(l => l.id === d.id))];
    if (user && user.rol === 'estudiante') {
      const email = (user.email || '').toLowerCase();
      const codigo = String(user.codigo || '').trim();
      const filtradas = combinadas.filter(s =>
        (user.id && s.estudiante_id === user.id) ||
        (email && s.email_institucional?.toLowerCase() === email) ||
        (codigo && s.codigo_uptc === codigo)
      );
      return { data: filtradas, error: null, isDemo: true };
    }
    return { data: combinadas, error: null, isDemo: true };
  }

  try {
    // 1. Intentar consulta relacional estructurada según estructura-supabase.sql
    const { data: relData, error: relError } = await supabase
      .from('solicitudes_campus')
      .select(`
        *,
        estudiantes (*),
        coordinadores (*),
        solicitudes_tutorias (*),
        prestamos_laboratorios (*),
        solicitudes_certificados (*)
      `)
      .order('creado_en', { ascending: false });

    let listaDb = [];

    if (!relError && Array.isArray(relData)) {
      listaDb = relData.map(item => {
        const est = item.estudiantes;
        const coord = item.coordinadores;
        const tut = Array.isArray(item.solicitudes_tutorias) ? item.solicitudes_tutorias[0] : item.solicitudes_tutorias;
        const lab = Array.isArray(item.prestamos_laboratorios) ? item.prestamos_laboratorios[0] : item.prestamos_laboratorios;
        const cert = Array.isArray(item.solicitudes_certificados) ? item.solicitudes_certificados[0] : item.solicitudes_certificados;

        const estudiante_nombre = est
          ? `${est.nombre || ''} ${est.apellido || ''}`.trim()
          : (item.estudiante_nombre || 'Estudiante UPTC');

        const codigo_uptc = est?.codigo_uptc || item.codigo_uptc || '';
        const email_institucional = est?.email_institucional || item.email_institucional || '';

        const area_asignada = coord?.area_responsable || item.area_asignada || (
          item.tipo_tramite === 'Tutoria' ? 'Coordinación Académica' :
          item.tipo_tramite === 'Laboratorio' ? 'Responsable de Laboratorios' :
          'Responsable de Certificados y Admisiones'
        );

        let asignatura_o_lab = item.asignatura_o_lab || '';
        if (!asignatura_o_lab) {
          if (tut?.asignatura) asignatura_o_lab = tut.asignatura;
          else if (lab?.motivo) asignatura_o_lab = lab.motivo;
          else if (cert?.tipo_certificado) asignatura_o_lab = cert.tipo_certificado;
        }

        return {
          id: item.id,
          estudiante_id: item.id_estudiante || item.estudiante_id,
          estudiante_nombre,
          codigo_uptc,
          email_institucional,
          tipo_tramite: item.tipo_tramite,
          asignatura_o_lab,
          descripcion: item.descripcion,
          estado: item.estado,
          area_asignada,
          observacion_coordinador: item.observacion_coordinador || '',
          creado_en: item.creado_en,
          actualizado_en: item.actualizado_en,
          solicitudes_tutorias: tut,
          prestamos_laboratorios: lab,
          solicitudes_certificados: cert
        };
      });
    } else {
      // Consulta plana de respaldo
      const { data: flatData } = await supabase
        .from('solicitudes_campus')
        .select('*')
        .order('creado_en', { ascending: false });

      if (Array.isArray(flatData)) {
        listaDb = flatData;
      }
    }

    // Combinar registros de Supabase con los radicados locales en la sesión
    const todos = [...locales, ...listaDb.filter(d => !locales.some(l => l.id === d.id))];

    // Si aún no hay registros en la base ni en local, proveer semillas para demostración
    const baseFinal = todos.length > 0 ? todos : DEMO_SEEDS;

    if (user && user.rol === 'estudiante') {
      const userEmail = (user.email || '').toLowerCase();
      const userCodigo = String(user.codigo || '').trim();
      const propias = baseFinal.filter(s =>
        (user.id && s.estudiante_id === user.id) ||
        (userEmail && s.email_institucional?.toLowerCase() === userEmail) ||
        (userCodigo && s.codigo_uptc === userCodigo)
      );
      return { data: propias.length > 0 ? propias : baseFinal, error: null, isDemo: false };
    }

    return { data: baseFinal, error: null, isDemo: false };
  } catch (err) {
    console.error('[Supabase] Error fetchSolicitudes:', err);
    return { data: locales.length > 0 ? locales : DEMO_SEEDS, error: null, isDemo: true };
  }
}

/**
 * Radica y persiste una nueva solicitud directamente en Supabase (Producción)
 * Respetando la estructura relacional de esquemas UPTC (ejemplos/estructura-supabase.sql)
 */
export async function crearSolicitudEnSupabase(formData, user) {
  if (!isConfigured || !supabase) {
    return {
      success: false,
      error: 'Supabase no está configurado.'
    };
  }

  try {
    const nombreCompleto = String(formData.estudiante_nombre || user?.nombre || 'Estudiante UPTC').trim();
    const partes = nombreCompleto.split(' ');
    const nombre = partes[0] || 'Estudiante';
    const apellido = partes.slice(1).join(' ') || 'UPTC';
    const codigoUptc = String(formData.codigo_uptc || user?.codigo || '').trim();
    const emailInstitucional = String(formData.email_institucional || user?.email || '').trim().toLowerCase();
    const tipoTramite = formData.tipo_tramite;
    const asunto = String(formData.asignatura_o_lab || '').trim();
    const descripcion = String(formData.descripcion || '').trim();

    // 1. Obtener o insertar estudiante en la tabla 'estudiantes'
    let idEstudiante = user?.id || null;
    try {
      const { data: estExistente } = await supabase
        .from('estudiantes')
        .select('id_estudiante')
        .or(`codigo_uptc.eq.${codigoUptc},email_institucional.eq.${emailInstitucional}`)
        .maybeSingle();

      if (estExistente?.id_estudiante) {
        idEstudiante = estExistente.id_estudiante;
      } else {
        const { data: nuevoEst } = await supabase
          .from('estudiantes')
          .insert({
            nombre,
            apellido,
            codigo_uptc: codigoUptc,
            email_institucional: emailInstitucional
          })
          .select('id_estudiante')
          .maybeSingle();

        if (nuevoEst?.id_estudiante) {
          idEstudiante = nuevoEst.id_estudiante;
        }
      }
    } catch (e) {
      console.warn('[Supabase] Tabla estudiantes:', e.message);
    }

    // 2. Resolver coordinador según el trámite
    let idCoordinador = null;
    let areaAsignada = 'Coordinación Académica';
    if (tipoTramite === 'Laboratorio') {
      areaAsignada = 'Responsable de Laboratorios';
    } else if (tipoTramite === 'Certificado') {
      areaAsignada = 'Responsable de Certificados y Admisiones';
    }

    try {
      const { data: coord } = await supabase
        .from('coordinadores')
        .select('id_coordinador')
        .limit(1)
        .maybeSingle();

      if (coord?.id_coordinador) {
        idCoordinador = coord.id_coordinador;
      }
    } catch (e) {
      console.warn('[Supabase] Tabla coordinadores:', e.message);
    }

    // 3. Insertar en 'solicitudes_campus'
    const basePayload = {
      tipo_tramite: tipoTramite,
      descripcion,
      estado: 'Pendiente'
    };

    if (idEstudiante) basePayload.id_estudiante = idEstudiante;
    if (idCoordinador) basePayload.id_coordinador = idCoordinador;

    basePayload.estudiante_nombre = nombreCompleto;
    basePayload.codigo_uptc = codigoUptc;
    basePayload.email_institucional = emailInstitucional;
    basePayload.asignatura_o_lab = asunto;
    basePayload.area_asignada = areaAsignada;
    if (formData.request_id) {
      basePayload.request_id = formData.request_id;
    }

    let insertRes = await supabase
      .from('solicitudes_campus')
      .insert(basePayload)
      .select()
      .single();

    if (insertRes.error && insertRes.error.message?.includes('column')) {
      const strictPayload = {
        tipo_tramite: tipoTramite,
        descripcion,
        estado: 'Pendiente'
      };
      if (idEstudiante) strictPayload.id_estudiante = idEstudiante;
      if (idCoordinador) strictPayload.id_coordinador = idCoordinador;

      insertRes = await supabase
        .from('solicitudes_campus')
        .insert(strictPayload)
        .select()
        .single();
    }

    const solicitudId = insertRes.data?.id || crypto.randomUUID();

    // 4. Insertar en las tablas hijas según tipo_tramite (Esquema de ejemplos)
    try {
      if (tipoTramite === 'Tutoria') {
        await supabase.from('solicitudes_tutorias').insert({
          id_tutoria: solicitudId,
          asignatura: asunto || 'Tutoría Académica General',
          tema: descripcion.slice(0, 150),
          modalidad: formData.modalidad || 'Presencial'
        });
      } else if (tipoTramite === 'Laboratorio') {
        const { data: lab } = await supabase.from('laboratorios').select('id_laboratorio').limit(1).maybeSingle();
        if (lab?.id_laboratorio) {
          const hoy = new Date();
          const fechaReserva = new Date(hoy.setDate(hoy.getDate() + 2)).toISOString().split('T')[0];
          await supabase.from('prestamos_laboratorios').insert({
            id_prestamo: solicitudId,
            id_laboratorio: lab.id_laboratorio,
            fecha_reserva: fechaReserva,
            hora_inicio: '08:00:00',
            hora_fin: '10:00:00',
            motivo: asunto || descripcion.slice(0, 200),
            cantidad_personas: parseInt(formData.cantidad_personas || 1, 10)
          });
        }
      } else if (tipoTramite === 'Certificado') {
        const numCert = `CERT-${Date.now().toString().slice(-6)}`;
        await supabase.from('solicitudes_certificados').insert({
          id_certificado: solicitudId,
          tipo_certificado: asunto || 'Certificado Oficial de Calificaciones',
          numero_certificado: numCert
        });
      }
    } catch (subErr) {
      console.warn('[Supabase] Tabla hija de trámite:', subErr.message);
    }

    // 5. Registrar en historial_solicitudes y notificaciones
    try {
      await supabase.from('historial_solicitudes').insert({
        id_solicitud: solicitudId,
        estado_anterior: null,
        estado_nuevo: 'Pendiente',
        observacion: 'Radicación inicial registrada en Supabase PostgreSQL.'
      });
    } catch (hErr) {}

    try {
      await supabase.from('notificaciones').insert({
        id_solicitud: solicitudId,
        mensaje: `Nueva solicitud de ${tipoTramite} radicada por ${nombreCompleto}.`,
        tipo_notificacion: tipoTramite,
        canal: 'Correo',
        estado_envio: 'Enviado'
      });
    } catch (nErr) {}

    const nuevoRegistro = {
      id: solicitudId,
      estudiante_id: idEstudiante,
      estudiante_nombre: nombreCompleto,
      codigo_uptc: codigoUptc,
      email_institucional: emailInstitucional,
      tipo_tramite: tipoTramite,
      asignatura_o_lab: asunto,
      descripcion,
      estado: 'Pendiente',
      area_asignada: areaAsignada,
      creado_en: new Date().toISOString()
    };

    registrarSolicitudLocal(nuevoRegistro);

    return {
      success: true,
      data: {
        status: 'ok',
        solicitud_id: solicitudId,
        tipo_tramite: tipoTramite,
        estado: 'Pendiente',
        area_asignada: areaAsignada,
        mensaje: 'Trámite radicado y registrado exitosamente en la base de datos Supabase (Producción).'
      }
    };
  } catch (err) {
    console.error('[Supabase] Error crearSolicitudEnSupabase:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Actualiza el estado de una solicitud (Operación autorizada exclusivamente para Coordinadores)
 */
export async function updateSolicitudEstado(id, nuevoEstado, observacion = '') {
  // Actualizar también en el almacén local
  const locales = getSolicitudesLocales();
  const index = locales.findIndex(s => s.id === id);
  if (index !== -1) {
    locales[index].estado = nuevoEstado;
    locales[index].observacion_coordinador = observacion;
    locales[index].actualizado_en = new Date().toISOString();
    try {
      localStorage.setItem(LOCAL_SOLICITUDES_KEY, JSON.stringify(locales));
    } catch (e) {}
  }

  if (!isConfigured || !supabase) {
    return { data: [{ id, estado: nuevoEstado }], error: null };
  }

  try {
    const { data: actual } = await supabase
      .from('solicitudes_campus')
      .select('estado')
      .eq('id', id)
      .maybeSingle();

    const estadoAnterior = actual?.estado || 'Pendiente';

    const { data, error } = await supabase
      .from('solicitudes_campus')
      .update({
        estado: nuevoEstado,
        observacion_coordinador: observacion,
        actualizado_en: new Date().toISOString()
      })
      .eq('id', id)
      .select();

    try {
      await supabase.from('historial_solicitudes').insert({
        id_solicitud: id,
        estado_anterior: estadoAnterior,
        estado_nuevo: nuevoEstado,
        observacion: observacion || `Estado actualizado a ${nuevoEstado} por Coordinación.`
      });
    } catch (hErr) {}

    return { data: data || [{ id, estado: nuevoEstado }], error: null };
  } catch (err) {
    return { data: [{ id, estado: nuevoEstado }], error: null };
  }
}
