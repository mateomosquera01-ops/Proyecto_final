/**
 * Módulo de Autenticación y Autorización en Producción
 * Gestiona la sesión real mediante Supabase Auth y resolución autorizada de roles
 * contra las tablas 'coordinadores', 'estudiantes' y 'perfiles' de Supabase.
 */

import { supabase, isConfigured } from './supabase';

const IS_DEV = import.meta.env.DEV;
const DEMO_ENABLED = IS_DEV && import.meta.env.VITE_ENABLE_DEMO_MODE === 'true';

export const isDemoModeAvailable = () => DEMO_ENABLED;

/**
 * Obtiene el usuario autenticado actual y su perfil con rol autorizado desde Supabase
 */
export async function getAuthenticatedUser() {
  if (!isConfigured || !supabase) {
    return { user: null, isConfigured: false };
  }

  try {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !session?.user) {
      return { user: null, isConfigured: true };
    }

    const authUser = session.user;
    const email = (authUser.email || '').toLowerCase();

    let rol = 'estudiante';
    let nombre = authUser.user_metadata?.nombre || authUser.email.split('@')[0];
    let codigo = authUser.user_metadata?.codigo || '';

    // 1. Verificar si el usuario es Coordinador en la tabla 'coordinadores' (Esquema de ejemplos)
    try {
      const { data: coord } = await supabase
        .from('coordinadores')
        .select('*')
        .ilike('email_institucional', email)
        .maybeSingle();

      if (coord) {
        rol = 'coordinador_general';
        nombre = `${coord.nombre || ''} ${coord.apellido || ''}`.trim() || nombre;
      }
    } catch (e) {
      // Ignorar si no existe
    }

    // 2. Si no es coordinador, verificar en 'estudiantes' (Esquema de ejemplos)
    if (rol === 'estudiante') {
      try {
        const { data: est } = await supabase
          .from('estudiantes')
          .select('*')
          .ilike('email_institucional', email)
          .maybeSingle();

        if (est) {
          nombre = `${est.nombre || ''} ${est.apellido || ''}`.trim() || nombre;
          codigo = est.codigo_uptc || codigo;
        }
      } catch (e) {
        // Ignorar si no existe
      }
    }

    // 3. Verificar si existe perfil en tabla 'perfiles'
    try {
      const { data: perfil } = await supabase
        .from('perfiles')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      if (perfil?.rol) {
        rol = perfil.rol;
        nombre = perfil.nombre_completo || nombre;
        codigo = perfil.codigo_uptc || codigo;
      }
    } catch (e) {
      // Ignorar si tabla perfiles no está presente
    }

    return {
      user: {
        id: authUser.id,
        email: authUser.email,
        nombre,
        codigo,
        rol,
        token: session.access_token,
        isDemo: false
      },
      isConfigured: true
    };
  } catch (err) {
    console.error('[AuthService] Error al consultar sesión:', err.message);
    return { user: null, isConfigured: true, error: err.message };
  }
}

/**
 * Inicio de sesión real con Supabase Auth
 */
export async function loginWithSupabase(email, password) {
  if (!isConfigured || !supabase) {
    return {
      success: false,
      error: 'Supabase Auth no está configurado en las variables de entorno.'
    };
  }

  // Validación de dominio institucional
  if (!email.toLowerCase().endsWith('@uptc.edu.co')) {
    return {
      success: false,
      error: 'El correo debe pertenecer exclusivamente al dominio institucional @uptc.edu.co.'
    };
  }

  try {
    const emailLimpio = email.trim().toLowerCase();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: emailLimpio,
      password
    });

    if (error) {
      return { success: false, error: error.message };
    }

    // Resolver rol y datos desde coordinadores / estudiantes
    let rol = 'estudiante';
    let nombre = data.user.user_metadata?.nombre || data.user.email.split('@')[0];
    let codigo = data.user.user_metadata?.codigo || '';

    try {
      const { data: coord } = await supabase
        .from('coordinadores')
        .select('*')
        .ilike('email_institucional', emailLimpio)
        .maybeSingle();

      if (coord) {
        rol = 'coordinador_general';
        nombre = `${coord.nombre || ''} ${coord.apellido || ''}`.trim() || nombre;
      }
    } catch (e) {}

    if (rol === 'estudiante') {
      try {
        const { data: est } = await supabase
          .from('estudiantes')
          .select('*')
          .ilike('email_institucional', emailLimpio)
          .maybeSingle();

        if (est) {
          nombre = `${est.nombre || ''} ${est.apellido || ''}`.trim() || nombre;
          codigo = est.codigo_uptc || codigo;
        }
      } catch (e) {}
    }

    return {
      success: true,
      user: {
        id: data.user.id,
        email: data.user.email,
        nombre,
        codigo,
        rol,
        token: data.session?.access_token,
        isDemo: false
      }
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Registro de nuevo estudiante con Supabase Auth y registro en tabla 'estudiantes'
 */
export async function registerWithSupabase({ email, password, nombre, codigo }) {
  if (!isConfigured || !supabase) {
    return {
      success: false,
      error: 'Supabase Auth no está configurado.'
    };
  }

  if (!email.toLowerCase().endsWith('@uptc.edu.co')) {
    return {
      success: false,
      error: 'El correo debe ser institucional y terminar en @uptc.edu.co.'
    };
  }

  if (!/^[0-9]{9}$/.test(String(codigo).trim())) {
    return {
      success: false,
      error: 'El código UPTC debe contener exactamente 9 dígitos.'
    };
  }

  try {
    const emailLimpio = email.trim().toLowerCase();
    const nombreLimpio = nombre.trim();
    const codigoLimpio = String(codigo).trim();

    const { data, error } = await supabase.auth.signUp({
      email: emailLimpio,
      password,
      options: {
        data: {
          nombre: nombreLimpio,
          codigo: codigoLimpio,
          rol: 'estudiante'
        }
      }
    });

    if (error) {
      return { success: false, error: error.message };
    }

    // Registrar también en la tabla 'estudiantes' de la base de datos (Esquema de ejemplos)
    try {
      const partes = nombreLimpio.split(' ');
      await supabase.from('estudiantes').insert({
        nombre: partes[0] || 'Estudiante',
        apellido: partes.slice(1).join(' ') || 'UPTC',
        codigo_uptc: codigoLimpio,
        email_institucional: emailLimpio
      });
    } catch (e) {
      console.warn('[AuthService] Registro en tabla estudiantes:', e.message);
    }

    return {
      success: true,
      message: 'Registro exitoso. Se ha vinculado su usuario a la base de datos de Supabase.'
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Cierre de sesión real
 */
export async function logoutUser() {
  if (isConfigured && supabase) {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('[AuthService] Error en signOut:', e.message);
    }
  }
}

/**
 * Modo Demostración Local (Exclusivo para Desarrollo Local)
 */
export function getLocalDemoUser(tipo = 'estudiante') {
  if (!DEMO_ENABLED) {
    return null;
  }

  if (tipo === 'coordinador') {
    return {
      id: 'demo-coordinador-local',
      nombre: 'Coordinador Demo (Solo Desarrollo)',
      email: 'demo.coordinacion@uptc.edu.co',
      codigo: '999999999',
      rol: 'coordinador_general',
      isDemo: true
    };
  }

  return {
    id: 'demo-estudiante-local',
    nombre: 'Estudiante Demo (Solo Desarrollo)',
    email: 'demo.estudiante@uptc.edu.co',
    codigo: '202410001',
    rol: 'estudiante',
    isDemo: true
  };
}
